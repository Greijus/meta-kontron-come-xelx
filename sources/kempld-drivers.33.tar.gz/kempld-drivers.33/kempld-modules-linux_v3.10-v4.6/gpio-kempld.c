/*
 *  kempld_gpio.c - Kontron PLD GPIO driver
 *
 *  Copyright (c) 2010-2014 Kontron Europe GmbH
 *  Author: Michael Brunner <michael.brunner@kontron.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License 2 as published
 *  by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

#include <linux/version.h>
#define __NO_VERSION__  /* don't define the kernel version global variable */
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/io.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <linux/acpi.h>
#include <linux/platform_device.h>
#include <linux/gpio.h>
#include "include/linux/mfd/kempld.h"
#include <linux/seq_file.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 5, 0))
#define GPIO_CHIP_DEV	chip->parent
#else
#define GPIO_CHIP_DEV	chip->dev
#endif

#include "gpio-kempld.h"

static int gpiobase = -1; /* dynamic */
module_param(gpiobase, int, 0444);
MODULE_PARM_DESC(gpiobase, "Set GPIO base (default -1=dynamic)");

static int gpioien; /* = 0x00 */
module_param(gpioien, int, 0444);
MODULE_PARM_DESC(gpioien, "Set GPIO IEN register (default 0x00)");

static int gpioevt_lvl_edge = -1; /* no change */
module_param(gpioevt_lvl_edge, int, 0444);
MODULE_PARM_DESC(gpioevt_lvl_edge,
		 "Set GPIO EVT_LVL_EDGE register (default -1=no change)");

static int gpioevt_low_high = -1; /* no change */
module_param(gpioevt_low_high, int, 0444);
MODULE_PARM_DESC(gpioevt_low_high,
		 "Set GPIO EVT_LOW_HIGH register (default -1=no change)");

static int gpionmien; /* = 0x00; */
module_param(gpionmien, int, 0444);
MODULE_PARM_DESC(gpionmien, "Set GPIO NMIEN register (default 0x00)");

static int gpio_irq = -1;
module_param(gpio_irq, int, 0);
MODULE_PARM_DESC(gpio_irq, "Set legacy GPIO IRQ (1-15)");

static bool restore_state;
module_param(restore_state, bool, 0);
MODULE_PARM_DESC(restore_state,
		 "Restore GPIO state after resume [default 0=no]");

static int kempld_gpio_get(struct gpio_chip *chip, unsigned offset)
{
	struct kempld_gpio_data *gpio
		= container_of(chip, struct kempld_gpio_data, chip);
	struct kempld_device_data *pld = gpio->pld;
	int status;

	pld = gpio->pld;

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_LVL_NUM(offset));

	status = kempld_read8(pld, KEMPLD_GPIO_LVL_NUM(offset));
	status &= KEMPLD_GPIO_MASK(offset);

	kempld_release_mutex(pld);

	return status;
}

static void kempld_gpio_set(struct gpio_chip *chip, unsigned offset,
			    int value)
{
	struct kempld_gpio_data *gpio
		= container_of(chip, struct kempld_gpio_data, chip);
	struct kempld_device_data *pld = gpio->pld;
	int status;


	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_LVL_NUM(offset));

	status = kempld_read8(pld, KEMPLD_GPIO_LVL_NUM(offset));
	if (value)
		status |= KEMPLD_GPIO_MASK(offset);
	else
		status &= ~KEMPLD_GPIO_MASK(offset);
	kempld_write8(pld, KEMPLD_GPIO_LVL_NUM(offset), status);

	kempld_release_mutex(pld);
}

static int kempld_gpio_direction_input(struct gpio_chip *chip, unsigned offset)
{
	struct kempld_gpio_data *gpio
		= container_of(chip, struct kempld_gpio_data, chip);
	struct kempld_device_data *pld = gpio->pld;
	int status;

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_DIR_NUM(offset));

	status = kempld_read8(pld, KEMPLD_GPIO_DIR_NUM(offset));
	status &= ~KEMPLD_GPIO_MASK(offset);
	kempld_write8(pld, KEMPLD_GPIO_DIR_NUM(offset), status);

	kempld_release_mutex(pld);


	return 0;
}

static int kempld_gpio_direction_output(struct gpio_chip *chip,
					 unsigned offset, int value)
{
	struct kempld_gpio_data *gpio
		= container_of(chip, struct kempld_gpio_data, chip);
	struct kempld_device_data *pld = gpio->pld;
	int status;

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_LVL_NUM(offset));

	status = kempld_read8(pld, KEMPLD_GPIO_LVL_NUM(offset));
	if (value)
		status |= KEMPLD_GPIO_MASK(offset);
	else
		status &= ~KEMPLD_GPIO_MASK(offset);
	kempld_write8(pld, KEMPLD_GPIO_LVL_NUM(offset), status);

	status = kempld_read8(pld, KEMPLD_GPIO_DIR_NUM(offset));
	status |= KEMPLD_GPIO_MASK(offset);
	kempld_write8(pld, KEMPLD_GPIO_DIR_NUM(offset), status);

	kempld_release_mutex(pld);

	return 0;
}

static int kempld_gpio_to_irq(struct gpio_chip *chip, unsigned offset)
{
	struct kempld_gpio_data *gpio
		= container_of(chip, struct kempld_gpio_data, chip);
	return gpio->irq;
}

#ifdef CONFIG_DEBUG_FS
static int kempld_gpio_get_direction(struct gpio_chip *chip, unsigned offset)
{
	struct kempld_gpio_data *gpio
		= container_of(chip, struct kempld_gpio_data, chip);
	struct kempld_device_data *pld = gpio->pld;
	int status;

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_DIR_NUM(offset));

	status = kempld_read8(pld, KEMPLD_GPIO_DIR_NUM(offset));
	status &= KEMPLD_GPIO_MASK(offset);

	kempld_release_mutex(pld);


	return status ? 1 : 0;
}

static int kempld_gpio_get_ien(struct gpio_chip *chip, unsigned offset)
{
	struct kempld_gpio_data *gpio
		= container_of(chip, struct kempld_gpio_data, chip);
	struct kempld_device_data *pld = gpio->pld;
	int status;

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_IEN_NUM(offset));

	status = kempld_read8(pld, KEMPLD_GPIO_IEN_NUM(offset));
	status &= KEMPLD_GPIO_MASK(offset);

	kempld_release_mutex(pld);


	return status ? 1 : 0;
}

static int kempld_gpio_get_evt_lvl_edge(struct gpio_chip *chip,
					unsigned offset)
{
	struct kempld_gpio_data *gpio
		= container_of(chip, struct kempld_gpio_data, chip);
	struct kempld_device_data *pld = gpio->pld;
	int status;

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_EVT_LVL_EDGE_NUM(offset));

	status = kempld_read8(pld, KEMPLD_GPIO_EVT_LVL_EDGE_NUM(offset));
	status &= KEMPLD_GPIO_MASK(offset);

	kempld_release_mutex(pld);


	return status ? 1 : 0;
}

static int kempld_gpio_get_evt_high_low(struct gpio_chip *chip,
					unsigned offset)
{
	struct kempld_gpio_data *gpio
		= container_of(chip, struct kempld_gpio_data, chip);
	struct kempld_device_data *pld = gpio->pld;
	int status;

	gpio = dev_get_drvdata(GPIO_CHIP_DEV);
	pld = gpio->pld;

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_EVT_LOW_HIGH_NUM(offset));

	status = kempld_read8(pld, KEMPLD_GPIO_EVT_LOW_HIGH_NUM(offset));
	status &= KEMPLD_GPIO_MASK(offset);

	kempld_release_mutex(pld);


	return status ? 1 : 0;
}

static int kempld_gpio_get_nmien(struct gpio_chip *chip, unsigned offset)
{
	struct kempld_gpio_data *gpio
		= container_of(chip, struct kempld_gpio_data, chip);
	struct kempld_device_data *pld = gpio->pld;
	int status;

	gpio = dev_get_drvdata(GPIO_CHIP_DEV);
	pld = gpio->pld;

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_NMIEN_NUM(offset));

	status = kempld_read8(pld, KEMPLD_GPIO_NMIEN_NUM(offset));
	status &= KEMPLD_GPIO_MASK(offset);

	kempld_release_mutex(pld);


	return status ? 1 : 0;
}

static void kempld_gpio_dbg_show(struct seq_file *s, struct gpio_chip *chip)
{
	int i;

	for (i = 0; i < chip->ngpio; i++) {
		int gpio = i + chip->base;

		seq_printf(s, " gpio-%-3d %s %s", gpio,
			   kempld_gpio_get_direction(chip, i) ? "out" : "in",
			   kempld_gpio_get(chip, i) ? "hi" : "lo");
		seq_printf(s, ", event on %s (irq %s, nmi %s)\n",
			   (kempld_gpio_get_evt_lvl_edge(chip, i)
			    ? (kempld_gpio_get_evt_high_low(chip, i)
			       ? "rising edge" : "falling edge") :
			    (kempld_gpio_get_evt_high_low(chip, i)
			     ? "high level" : "low level")),
			   kempld_gpio_get_ien(chip, i)
			   ? "enabled" : "disabled",
			   kempld_gpio_get_nmien(chip, i)
			   ? "enabled" : "disabled");
	}
}
#else
#define kempld_gpio_dbg_show NULL
#endif

static int kempld_gpio_setup_event(struct kempld_gpio_data *gpio)
{
	struct kempld_device_data *pld = gpio->pld;
	struct gpio_chip *chip = &gpio->chip;
	int irq;

	irq = gpio->irq;

	kempld_get_mutex_set_index(pld, KEMPLD_IRQ_GPIO);
		if ((gpio_irq > 0) && (gpio_irq <= 15))
			kempld_write8(pld, KEMPLD_IRQ_GPIO, gpio_irq);
		else if (gpio_irq != -1)
			dev_warn(pld->dev,
				 "GPIO IRQ option out of range - no change\n");

	irq = kempld_read8(pld, KEMPLD_IRQ_GPIO);

	/* Leave if interrupts are not supported by the GPIO core */
	if ((irq & 0xf0) == 0xf0) {
		kempld_release_mutex(pld);
		return 0;
	}

	gpio->irq = irq & 0x0f;

	if (gpioien & !gpio->mask) {
		dev_err(GPIO_CHIP_DEV, "gpioien parameter is invalid");
		gpio->irq = 0;
	}

	if (gpionmien & !gpio->mask) {
		dev_err(GPIO_CHIP_DEV, "gpionmien parameter is invalid");
		gpio->irq = 0;
	}

	if ((gpioevt_lvl_edge & !gpio->mask) && (gpioevt_lvl_edge != -1)) {
		dev_err(GPIO_CHIP_DEV, "gpioevt_lvl_edge parameter is invalid");
		gpio->irq = 0;
	}

	if ((gpioevt_low_high & !gpio->mask) && (gpioevt_low_high != -1)) {
		dev_err(GPIO_CHIP_DEV, "gpioevt_low_high parameter is invalid");
		gpio->irq = 0;
	}

	if (!gpio->irq) {
		kempld_release_mutex(pld);
		return -EIO;
	}

	if (gpioevt_lvl_edge != -1)
		kempld_write16(pld, KEMPLD_GPIO_EVT_LVL_EDGE,
			       gpioevt_lvl_edge);

	if (gpioevt_low_high != -1)
		kempld_write16(pld, KEMPLD_GPIO_EVT_LOW_HIGH,
			       gpioevt_low_high);

	kempld_write16(pld, KEMPLD_GPIO_NMIEN, gpionmien);
	kempld_write16(pld, KEMPLD_GPIO_IEN, gpioien);

	kempld_release_mutex(pld);

	return 0;
}


static int kempld_gpio_detect(struct kempld_gpio_data *gpio)
{
	struct kempld_device_data *pld = gpio->pld;
	struct gpio_chip *chip = &gpio->chip;
	u16 evt, evt_back;
	int i;

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_IEN);

	/* Backup event register as it might be already initialized */
	evt_back = kempld_read16(pld, KEMPLD_GPIO_EVT_LVL_EDGE);

	/* Disable interrupt enables and set event register to zero */
	kempld_write16(pld, KEMPLD_GPIO_IEN, 0x0000);
	kempld_write16(pld, KEMPLD_GPIO_NMIEN, 0x0000);
	kempld_write16(pld, KEMPLD_GPIO_EVT_LVL_EDGE, 0x0000);

	/* Read back event register */
	evt = kempld_read16(pld, KEMPLD_GPIO_EVT_LVL_EDGE);

	/* Restore event register */
	kempld_write16(pld, KEMPLD_GPIO_EVT_LVL_EDGE, evt_back);

	kempld_release_mutex(pld);

	gpio->mask = ~evt;

	/* Now check how many GPIO pins we have */
	for (i = 0; i < KEMPLD_GPIO_MAX_NUM; i++) {
		if (evt & 0x1)
			break;
		evt >>= 1;
	}

	chip->ngpio = i;

	return 0;
}

static int kempld_gpio_probe(struct platform_device *pdev)
{
	struct device *dev = &pdev->dev;
	struct kempld_device_data *pld = dev_get_drvdata(dev->parent);
	struct kempld_gpio_data *gpio;
	struct gpio_chip *chip;
	int ret;


	if (pld->info.spec_major < 2) {
		dev_warn(dev,
			"driver only supports GPIO devices compatible to PLD spec. rev. 2.0 or higher\n");
		return -ENXIO;
	}

	gpio = devm_kzalloc(dev, sizeof(*gpio), GFP_KERNEL);
	if (gpio == NULL)
		return -ENOMEM;

	gpio->pld = pld;

	platform_set_drvdata(pdev, gpio);

	chip = &gpio->chip;
	chip->label =		"kempld-gpio";
	chip->owner =		THIS_MODULE;
	GPIO_CHIP_DEV =		dev;
	chip->can_sleep =	1;
	chip->base =		gpiobase;
	chip->ngpio =		KEMPLD_GPIO_MAX_NUM;

	if (kempld_gpio_detect(gpio))
		dev_warn(dev, "GPIO detection failed\n");
	if (kempld_gpio_setup_event(gpio))
		dev_info(dev, "GPIO irq disabled\n");

	chip->direction_input =		kempld_gpio_direction_input;
	chip->direction_output =	kempld_gpio_direction_output;
	chip->get =			kempld_gpio_get;
	chip->set =			kempld_gpio_set;
	chip->dbg_show =		kempld_gpio_dbg_show;
	if (gpio->irq)
		chip->to_irq =		kempld_gpio_to_irq;

	ret = gpiochip_add(chip);
	if (ret) {
		dev_err(dev, "Could not register GPIO chip\n");
		return ret;
	}

	dev_info(dev,
		 "GPIO functionality initialized with %d IOs mask (0x%04x)\n",
		 chip->ngpio, gpio->mask);

	return 0;
}

#ifdef CONFIG_PM
static int kempld_gpio_suspend(struct device *dev)
{
	struct kempld_gpio_data *gpio = dev_get_drvdata(dev);
	struct kempld_device_data *pld = dev_get_drvdata(dev->parent);

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_LVL);
	gpio->lvl_save = kempld_read16(pld, KEMPLD_GPIO_LVL);
	gpio->dir_save = kempld_read16(pld, KEMPLD_GPIO_DIR);
	kempld_release_mutex(pld);

	return 0;
}

static int kempld_gpio_resume(struct device *dev)
{
	struct kempld_gpio_data *gpio = dev_get_drvdata(dev);
	struct kempld_device_data *pld = dev_get_drvdata(dev->parent);

	/* As the driver has no runtime event handling we restore the driver
	 * defaults for GPIO events for now */
	kempld_gpio_setup_event(gpio);

	if (!restore_state)
		return 0;

	kempld_get_mutex_set_index(pld, KEMPLD_GPIO_LVL);
	kempld_write16(pld, KEMPLD_GPIO_LVL, gpio->lvl_save);
	kempld_write16(pld, KEMPLD_GPIO_DIR, gpio->dir_save);
	kempld_release_mutex(pld);

	return 0;
}
#endif

static int kempld_gpio_remove(struct platform_device *pdev)
{
	struct kempld_gpio_data *gpio = platform_get_drvdata(pdev);

	gpiochip_remove(&gpio->chip);

	return 0;
}

static const struct dev_pm_ops kempld_gpio_pm_ops = {
#ifdef CONFIG_PM_SLEEP
	.suspend = kempld_gpio_suspend,
	.resume = kempld_gpio_resume,
	.poweroff =  kempld_gpio_suspend,
	.restore = kempld_gpio_resume,
#endif
};

static struct platform_driver kempld_gpio_driver = {
	.driver = {
		.name = "kempld-gpio",
		.owner = THIS_MODULE,
		.pm = &kempld_gpio_pm_ops,
	},
	.probe		= kempld_gpio_probe,
	.remove		= kempld_gpio_remove,
};

static int __init kempld_gpio_init(void)
{
	return platform_driver_register(&kempld_gpio_driver);
}

static void __exit kempld_gpio_exit(void)
{
	platform_driver_unregister(&kempld_gpio_driver);
}

module_init(kempld_gpio_init);
module_exit(kempld_gpio_exit);

MODULE_DESCRIPTION("KEM PLD GPIO Driver");
MODULE_AUTHOR("Michael Brunner <michael.brunner@kontron.com>");
MODULE_LICENSE("GPL");
MODULE_ALIAS("platform:kempld-gpio");
MODULE_VERSION("33.0");
