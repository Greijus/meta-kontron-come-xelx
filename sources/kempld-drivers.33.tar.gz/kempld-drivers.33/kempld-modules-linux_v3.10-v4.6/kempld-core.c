/*
 *  kempld-core.c - Kontron PLD MFD core driver
 *
 *  Copyright (c) 2010-2014 Kontron Europe GmbH
 *  Author: Michael Brunner <michael.brunner@kontron.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License 2 as published
 *  by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

#include <linux/version.h>
#define __NO_VERSION__  /* don't define the kernel version global variable */
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/list.h>
#include <linux/device.h>
#include <linux/platform_device.h>
#include <linux/dmi.h>
#include <linux/slab.h>
#include <linux/io.h>
#include <linux/sched.h>
#include <linux/mfd/core.h>
#include "include/linux/mfd/kempld.h"

#define KEMPLD_MAINTAIN_EFT_COMPATIBILITY	1

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3, 6, 0))
#define mfd_add_devices(...)	mfd_add_devices(__VA_ARGS__, NULL)
#endif

static int kempld_platform_device_register(const struct dmi_system_id *id);
static int kempld_get_mutex_set_index_generic(struct kempld_device_data *pld,
				       u8 index, unsigned int timeout);
static void kempld_release_mutex_generic(struct kempld_device_data *pld);

static int kempld_get_info(struct kempld_device_data *pld);
static int kempld_get_info_NOW1(struct kempld_device_data *pld);
static int kempld_get_info_generic(struct kempld_device_data *pld);
static int kempld_get_features(struct kempld_device_data *pld);
static int kempld_register_cells_generic(struct kempld_device_data *pld);
static int kempld_register_cells_NOW1(struct kempld_device_data *pld);

#define MAX_ID_LEN 4
static char force_device_id[MAX_ID_LEN + 1] = "";
module_param_string(force_device_id, force_device_id,
		    sizeof(force_device_id), 0);
MODULE_PARM_DESC(force_device_id, "Override detected product");

/* this option is only here for debugging and should never be needed in
 * production environments */
static bool force_unlock;
module_param(force_unlock, bool, 0);
MODULE_PARM_DESC(force_unlock, "Force breaking the semaphore on driver load");

/* this is the default CPLD configuration unless something else is defined */
static const struct kempld_platform_data kempld_platform_data_generic = {
	.pld_clock		= 33333333,
	.ioport			= 0xa80,
	.force_index_write	= 0,
	.get_mutex_set_index	= kempld_get_mutex_set_index_generic,
	.release_mutex		= kempld_release_mutex_generic,
	.get_info		= kempld_get_info_generic,
	.register_cells		= kempld_register_cells_generic,
};

/* the COMe-mSP1 (nanoETXexpress-SP) has an earlier version of the CPLD that
 * works a bit different */
static const struct kempld_platform_data kempld_platform_data_NOW1 = {
	.pld_clock		= 33333333,
	.ioport			= 0xa80,
	.force_index_write	= 1,
	.get_mutex_set_index	= NULL,
	.release_mutex		= NULL,
	.get_info		= kempld_get_info_NOW1,
	.register_cells		= kempld_register_cells_NOW1,
};

static const struct dmi_system_id kempld_boardids[] = {
	{
		.callback = kempld_platform_device_register,
		.ident = "BBD6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bBD"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "BBL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bBL6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "BCL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bCL6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "BDV7",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bDV7"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "BHL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bHL6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "BKL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bKL"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "BSL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bSL6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CBL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cBL6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "BTL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bTL6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CAL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cAL"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CBW6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cBW6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CDV7",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cDV7"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CKL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cKL"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CTL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cTL6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CCR2",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bIP2"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CCR6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bIP6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CHL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cHL6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CHR2",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "ETXexpress-SC T2"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CHR2",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "ETXe-SC T2"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CHR2",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bSC2"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CHR6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "ETXexpress-SC T6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CHR6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "ETXe-SC T6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CHR6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bSC6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CNTG",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "ETXexpress-PC"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CNTG",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bPC2"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CNTX",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "PXT"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CSL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cSL6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CVR6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cVR6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "CVV6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cBT"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "FRI2",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BIOS_VERSION, "FRI2"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "FRI2",
		.matches = {
			DMI_MATCH(DMI_PRODUCT_NAME, "Fish River Island II"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "A203",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "KBox A-203"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "M4A1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-m4AL"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "MAL1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mAL"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "MAPL",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "mITX-APL"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "MBR1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "ETX-OH"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "MEL1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mEL"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "MVV1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mBT"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "NOW1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "nanoETXexpress-SP"),
		},
		.driver_data = (void *)&kempld_platform_data_NOW1,
	}, {
		.callback = kempld_platform_device_register,
		.ident = "NOW1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mSP1"),
		},
		.driver_data = (void *)&kempld_platform_data_NOW1,
	}, {
		.callback = kempld_platform_device_register,
		.ident = "NTC1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "nanoETXexpress-TT"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "NTC1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "nETXe-TT"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "NTC1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mTT"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "NUP1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mCT"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "PAPL",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "pITX-APL"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "SXAL",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "SMARC-sXAL"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "SXAL4",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "SMARC-sXA4"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "SXEL",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "SMARC-sXEL"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "UNP1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "microETXexpress-DC"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "UNP1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cDC2"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "UNTG",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "microETXexpress-PC"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "UNTG",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cPC2"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "UUP6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cCT6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "UTH6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cTH6"),
		},
	}, {
		.callback = kempld_platform_device_register,
		.ident = "Q7AL",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "Qseven-Q7AL"),
		},
	},
	/* The following are dummy entries, not representing actual products */
	{
		.callback = kempld_platform_device_register,
		.ident = "come",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "*come*"),
		}
	}, {
		.callback = kempld_platform_device_register,
		.ident = "gene",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "*generic*"),
		}
	},
	{}
};

static struct kempld_platform_data kempld_platform_data;

static struct mfd_cell kempld_cell_i2c = {
	.name = "kempld-i2c",
};

static struct mfd_cell kempld_cell_wdt = {
	.name = "kempld-wdt",
};

static struct mfd_cell kempld_cell_NOW1_wdt = {
	.name = "kempld_now1-wdt",
};

static struct mfd_cell kempld_cell_gpio = {
	.name = "kempld-gpio",
};

static struct mfd_cell kempld_cell_uart = {
	.name = "kempld-uart",
};

static struct mfd_cell kempld_cell_NOW1_gpio = {
	.name = "kempld_now1-gpio",
};

static struct platform_device *kempld_pdev;

static const char *kempld_get_type_string(struct kempld_device_data *pld)
{
	const char *version_type;

	switch (pld->info.type) {
	case 0:
		version_type = "release";
		break;
	case 1:
		version_type = "debug";
		break;
	case 2:
		version_type = "custom";
		break;
	default:
		version_type = "unspecified";
		break;
	}

	return version_type;
}

static ssize_t kempld_version_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	struct kempld_device_data *pld = dev_get_drvdata(dev);

	return scnprintf(buf, PAGE_SIZE, "%s\n", pld->info.version);
}

static ssize_t kempld_specification_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	struct kempld_device_data *pld = dev_get_drvdata(dev);

	return scnprintf(buf, PAGE_SIZE, "%d.%d\n", pld->info.spec_major,
		       pld->info.spec_minor);
}

static ssize_t kempld_type_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	struct kempld_device_data *pld = dev_get_drvdata(dev);

	return scnprintf(buf, PAGE_SIZE, "%s\n", kempld_get_type_string(pld));
}

static DEVICE_ATTR(pld_version, S_IRUGO, kempld_version_show, NULL);
static DEVICE_ATTR(pld_specification, S_IRUGO, kempld_specification_show,
		   NULL);
static DEVICE_ATTR(pld_type, S_IRUGO, kempld_type_show, NULL);

static struct attribute *pld_attributes[] = {
	&dev_attr_pld_version.attr,
	&dev_attr_pld_specification.attr,
	&dev_attr_pld_type.attr,
	NULL
};

static const struct attribute_group pld_attr_group = {
	.attrs = pld_attributes,
};

/**
 * kempld_read8 - read 8 bit register
 * @pld:   kempld_device_data structure describing the PLD
 * @index: register index on the chip
 *
 * This function reads an 8 bit register of the PLD and returns its value.
 *
 * In order for this function to work correctly, kempld_try_get_mutex_set_index
 * or kempld_get_mutex_set_index has to be called before calling the function
 * to acquire the mutex. Afterwards the mutex has to be released with
 * kempld_release_mutex.
 */
u8 kempld_read8(struct kempld_device_data *pld, u8 index)
{
	kempld_set_index(pld, index);

	return ioread8(pld->io_data);
}
EXPORT_SYMBOL(kempld_read8);

/**
 * kempld_write8 - write 8 bit register
 * @pld:   kempld_device_data structure describing the PLD
 * @index: register index on the chip
 * @data:  new register value
 *
 * This function writes an 8 bit register of the PLD.
 *
 * In order for this function to work correctly, kempld_try_get_mutex_set_index
 * or kempld_get_mutex_set_index has to be called before calling the function
 * to acquire the mutex. Afterwards the mutex has to be released with
 * kempld_release_mutex.
 */
void kempld_write8(struct kempld_device_data *pld, u8 index, u8 data)
{
	kempld_set_index(pld, index);

	iowrite8(data, pld->io_data);
}
EXPORT_SYMBOL(kempld_write8);

/**
 * kempld_read16 - read 16 bit register
 * @pld:   kempld_device_data structure describing the PLD
 * @index: register index on the chip
 *
 * This function reads a 16 bit register of the PLD and returns its value.
 *
 * In order for this function to work correctly, kempld_try_get_mutex_set_index
 * or kempld_get_mutex_set_index has to be called before calling the function
 * to acquire the mutex. Afterwards the mutex has to be released with
 * kempld_release_mutex.
 */
u16 kempld_read16(struct kempld_device_data *pld, u8 index)
{
	BUG_ON(index+1 < index);

	return kempld_read8(pld, index) | kempld_read8(pld, index+1) << 8;
}
EXPORT_SYMBOL(kempld_read16);

/**
 * kempld_write16 - write 16 bit register
 * @pld:   kempld_device_data structure describing the PLD
 * @index: register index on the chip
 * @data:  new register value
 *
 * This function writes a 16 bit register of the PLD.
 *
 * In order for this function to work correctly, kempld_try_get_mutex_set_index
 * or kempld_get_mutex_set_index has to be called before calling the function
 * to acquire the mutex. Afterwards the mutex has to be released with
 * kempld_release_mutex.
 */
void kempld_write16(struct kempld_device_data *pld, u8 index, u16 data)
{
	BUG_ON(index+1 < index);

	kempld_write8(pld, index, (u8)data);
	kempld_write8(pld, index+1, (u8)(data>>8));
}
EXPORT_SYMBOL(kempld_write16);

/**
 * kempld_read32 - read 32 bit register
 * @pld:   kempld_device_data structure describing the PLD
 * @index: register index on the chip
 *
 * This function reads a 32 bit register of the PLD and returns its value.
 *
 * In order for this function to work correctly, kempld_try_get_mutex_set_index
 * or kempld_get_mutex_set_index has to be called before calling the function
 * to acquire the mutex. Afterwards the mutex has to be released with
 * kempld_release_mutex.
 */
u32 kempld_read32(struct kempld_device_data *pld, u8 index)
{
	BUG_ON(index+3 < index);

	return kempld_read16(pld, index) | kempld_read16(pld, index+2) << 16;
}
EXPORT_SYMBOL(kempld_read32);

/**
 * kempld_write32 - write 32 bit register
 * @pld:   kempld_device_data structure describing the PLD
 * @index: register index on the chip
 * @data:  new register value
 *
 * This function writes a 32 bit register of the PLD.
 *
 * In order for this function to work correctly, kempld_try_get_mutex_set_index
 * or kempld_get_mutex_set_index has to be called before calling the function
 * to acquire the mutex. Afterwards the mutex has to be released with
 * kempld_release_mutex.
 */
void kempld_write32(struct kempld_device_data *pld, u8 index, u32 data)
{
	BUG_ON(index+3 < index);

	kempld_write16(pld, index, (u16)data);
	kempld_write16(pld, index+2, (u16)(data>>16));
}
EXPORT_SYMBOL(kempld_write32);

/**
 * kempld_set_index -  change the current register index of the PLD
 * @pld:   kempld_device_data structure describing the PLD
 * @index: register index on the chip
 *
 * This function changes the register index of the PLD.
 *
 * If the PLD mutex has been acquired the whole time and the desired index is
 * already set there might be no actual hardware access done in this function.
 *
 * In order for this function to work correctly, kempld_try_get_mutex_set_index
 * or kempld_get_mutex_set_index has to be called before calling the function
 * to acquire the mutex. Afterwards the mutex has to be released with
 * kempld_release_mutex.
 */
void kempld_set_index(struct kempld_device_data *pld, u8 index)
{
	struct kempld_platform_data *pdata = pld->dev->platform_data;

	BUG_ON(pld->have_mutex == 0);

	if (pld->last_index != index || pdata->force_index_write) {
		iowrite8(index, pld->io_index);
		pld->last_index = index;
	}
}
EXPORT_SYMBOL(kempld_set_index);

static int kempld_get_mutex_set_index_generic(struct kempld_device_data *pld,
				       u8 index, unsigned int timeout)
{
	struct kempld_platform_data *pdata = pld->dev->platform_data;
	int data;

	if (!pld->have_mutex) {
		unsigned long loop_timeout = jiffies + (HZ*timeout)/1000;

		while ((((data = ioread8(pld->io_index)) & KEMPLD_MUTEX_KEY)
		       == KEMPLD_MUTEX_KEY)) {
			if (timeout != KEMPLD_MUTEX_NOTIMEOUT)
				if (!time_before(jiffies, loop_timeout))
					return -ETIMEDOUT;

			/* we will have to wait until mutex is free */
			spin_unlock_irqrestore(&pld->lock, pld->lock_flags);

			/* give other tasks a chance to release the mutex */
			schedule_timeout_interruptible(0);

			spin_lock_irqsave(&pld->lock, pld->lock_flags);
		}
	} else
		data = ioread8(pld->io_index);

	if (KEMPLD_MAINTAIN_EFT_COMPATIBILITY
	     || ((pld->last_index != (data & ~KEMPLD_MUTEX_KEY))
	     || pdata->force_index_write)) {
		iowrite8(index, pld->io_index);
		pld->last_index = index;
	}

	return 0;
}

/**
 * kempld_get_mutex_set_index -  acquire the PLD mutex and set register index
 * @pld:   kempld_device_data structure describing the PLD
 * @index: register index on the chip
 *
 * This function acquires a PLD spinlock and the PLD mutex, additionally it
 * also changes the register index. In order to do no unnecessary write cycles
 * the index provided to this function should be the same that will be used
 * with the first PLD access that is done afterwards.
 *
 * The function will block for at least 10 seconds if the mutex can't be
 * acquired and issue a warning in that case. In order to not lock the device,
 * the function assumes that the mutex has been acquired in that case.
 *
 * To release the spinlock and mutex kempld_release_mutex can be called.
 * The spinlock and mutex should only be kept for a few milliseconds, in order
 * to give other drivers a chance to work with the PLD.
 */
inline void kempld_get_mutex_set_index(struct kempld_device_data *pld,
				       u8 index)
{
	struct kempld_platform_data *pdata = pld->dev->platform_data;

	spin_lock_irqsave(&pld->lock, pld->lock_flags);

	if (pdata->get_mutex_set_index) {
		/* use a long timeout here as this shouldn't fail */
		if (pdata->get_mutex_set_index(pld, index, 10000))
			dev_warn(pld->dev, "semaphore broken!\n");

		pld->have_mutex = 1;
	} else {
		pld->have_mutex = 1;
		kempld_set_index(pld, index);
	}
}
EXPORT_SYMBOL(kempld_get_mutex_set_index);

/**
 * kempld_try_get_mutex_set_index -  try to acquire the PLD mutex and set
 *                                   register index
 * @pld:     kempld_device_data structure describing the PLD
 * @index:   register index on the chip
 * @timeout: timeout value
 *
 * This function tries to acquire a PLD spinlock and the PLD mutex,
 * additionally it also changes the register index. In order to do no
 * unnecessary write cycles the index provided to this function should be the
 * same that will be used with the first PLD access that is done afterwards.
 *
 * The function will try to get the mutex for the time defined with the timeout
 * parameter until it returns with -ETIMEDOUT. When the mutex is successfully
 * acquired the function returns immediately with the return value 0.
 *
 * To release the spinlock and mutex kempld_release_mutex can be called.
 * The spinlock and mutex should only be kept for a few milliseconds, in order
 * to give other drivers a chance to work with the PLD.
 */
inline int kempld_try_get_mutex_set_index(struct kempld_device_data *pld,
					  u8 index, unsigned int timeout)
{
	int ret;
	struct kempld_platform_data *pdata = pld->dev->platform_data;

	spin_lock_irqsave(&pld->lock, pld->lock_flags);

	if (pdata->get_mutex_set_index) {
		ret = pdata->get_mutex_set_index(pld, index, timeout);
		if (ret == 0)
			pld->have_mutex = 1;
	} else {
		pld->have_mutex = 1;
		kempld_set_index(pld, index);
		ret = 0;
	}

	if (ret != 0)
		spin_unlock_irqrestore(&pld->lock, pld->lock_flags);

	return ret;
}
EXPORT_SYMBOL(kempld_try_get_mutex_set_index);

static void kempld_release_mutex_generic(struct kempld_device_data *pld)
{
	iowrite8(pld->last_index | KEMPLD_MUTEX_KEY, pld->io_index);
}

/**
 * kempld_release_mutex - release PLD mutex
 * @pld:     kempld_device_data structure describing the PLD
 *
 * This function releases the spinlock und mutex previously acquired with the
 * kempld_get_mutex_set_index or kempld_try_get_mutex_set_index functions.
 */
inline void kempld_release_mutex(struct kempld_device_data *pld)
{
	struct kempld_platform_data *pdata = pld->dev->platform_data;

	BUG_ON(pld->have_mutex == 0);

	if (pdata->release_mutex)
		pdata->release_mutex(pld);

	pld->have_mutex = 0;

	spin_unlock_irqrestore(&pld->lock, pld->lock_flags);
}
EXPORT_SYMBOL(kempld_release_mutex);

/**
 * kempld_get_info - update device specific information
 * @pld:     kempld_device_data structure describing the PLD
 *
 * This function calls the configured board specific kempld_get_info_XXXX
 * function which is responsible for gathering information about the specific
 * hardware. The information is then stored within the pld structure.
 */
static int kempld_get_info(struct kempld_device_data *pld)
{
	int ret;
	struct kempld_platform_data *pdata = dev_get_platdata(pld->dev);
	char major, minor;

	ret = pdata->get_info(pld);
	if (ret)
		return ret;

	/* The Kontron PLD firmware version string has the following format:
	 * Pwxy.zzzz
	 *   P:    Fixed
	 *   w:    PLD number    - 1 hex digit
	 *   x:    Major version - 1 alphanumerical digit (0-9A-V)
	 *   y:    Minor version - 1 alphanumerical digit (0-9A-V)
	 *   zzzz: Build number  - 4 zero padded hex digits */

	if (pld->info.major < 10)
		major = pld->info.major + '0';
	else
		major = (pld->info.major - 10) + 'A';
	if (pld->info.minor < 10)
		minor = pld->info.minor + '0';
	else
		minor = (pld->info.minor - 10) + 'A';

	ret = scnprintf(pld->info.version, sizeof(pld->info.version),
			"P%X%c%c.%04X", pld->info.number, major, minor,
			pld->info.buildnr);
	if (ret < 0)
		return ret;

	return 0;
}

static int kempld_get_info_NOW1(struct kempld_device_data *pld)
{
	kempld_get_mutex_set_index(pld, KEMPLD_VERSION_NOW1);

	pld->info.major = kempld_read8(pld, KEMPLD_VERSION_NOW1);
	pld->info.minor = 0;

	pld->info.buildnr = kempld_read8(pld, KEMPLD_BUILDNR_NOW1);

	pld->info.number = 0;
	pld->info.type = 0x0;

	pld->info.spec_major = 0;
	pld->info.spec_minor = 0;

	kempld_release_mutex(pld);

	return 0;
}

static int kempld_get_info_generic(struct kempld_device_data *pld)
{
	u16 data;

	kempld_get_mutex_set_index(pld, KEMPLD_VERSION);

	data = kempld_read16(pld, KEMPLD_VERSION);
	pld->info.minor = KEMPLD_VERSION_GET_MINOR(data);
	pld->info.major = KEMPLD_VERSION_GET_MAJOR(data);
	pld->info.number = KEMPLD_VERSION_GET_NUMBER(data);
	pld->info.type = KEMPLD_VERSION_GET_TYPE(data);
	pld->info.buildnr = kempld_read16(pld, KEMPLD_BUILDNR);

	data = kempld_read8(pld, KEMPLD_SPEC);
	if (data == 0xff) {
		pld->info.spec_minor = 0;
		pld->info.spec_major = 1;
	} else {
		pld->info.spec_minor = KEMPLD_SPEC_GET_MINOR(data);
		pld->info.spec_major = KEMPLD_SPEC_GET_MAJOR(data);
	}

	kempld_release_mutex(pld);

	return 0;
}

/**
 * kempld_get_features - retrieve features supported by device
 * @pld:     kempld_device_data structure describing the PLD
 *
 * This function tries to detect the features supported by the PLD device
 */
static int kempld_get_features(struct kempld_device_data *pld)
{
	if (pld->info.spec_major > 0) {
		kempld_get_mutex_set_index(pld, KEMPLD_FEATURE);

		pld->feature_mask = kempld_read16(pld, KEMPLD_FEATURE);

		kempld_release_mutex(pld);
	} else {
		/* No way to automatically detect the features, they have to
		 * be specified during cell registration */
		pld->feature_mask = 0;
	}

	return 0;
}

/*
 * kempld_register_cells - register cell drivers
 *
 * This function registers cell drivers for the detected hardware by calling
 * the configured kempld_register_cells_XXXX function which is responsible
 * to detect and register the needed cell drivers.
 */
static int kempld_register_cells(struct kempld_device_data *pld)
{
	struct kempld_platform_data *pdata = pld->dev->platform_data;

	if (pdata->register_cells)
		return pdata->register_cells(pld);

	dev_warn(pld->dev, "no subdevices are supported\n");

	return -ENODEV;
}

static int kempld_register_cells_NOW1(struct kempld_device_data *pld)
{

	/* The NOW1 has a fixed feature set that cannot be detected */

	pld->feature_mask = KEMPLD_FEATURE_BIT_WATCHDOG
		| KEMPLD_FEATURE_BIT_GPIO;

	mfd_add_devices(pld->dev, -1, &kempld_cell_NOW1_wdt, 1, NULL, 0);
	dev_info(pld->dev, "registered watchdog support\n");

	mfd_add_devices(pld->dev, -1, &kempld_cell_NOW1_gpio, 1, NULL, 0);
	dev_info(pld->dev, "registered GPIO support\n");

	return 0;
}

static int kempld_register_cells_generic(struct kempld_device_data *pld)
{
	if (pld->feature_mask & KEMPLD_FEATURE_BIT_I2C) {
		mfd_add_devices(pld->dev, -1, &kempld_cell_i2c, 1, NULL, 0);
		dev_info(pld->dev, "registered I2C support\n");
	}

	if (pld->feature_mask & KEMPLD_FEATURE_BIT_WATCHDOG) {
		mfd_add_devices(pld->dev, -1, &kempld_cell_wdt, 1, NULL, 0);
		dev_info(pld->dev, "registered watchdog support\n");
	}

	if (pld->feature_mask & KEMPLD_FEATURE_BIT_GPIO) {
		mfd_add_devices(pld->dev, -1, &kempld_cell_gpio, 1, NULL, 0);
		dev_info(pld->dev, "registered GPIO support\n");
	}

	if (pld->feature_mask & KEMPLD_FEATURE_MASK_UART) {
		mfd_add_devices(pld->dev, -1, &kempld_cell_uart, 1, NULL, 0);
		dev_info(pld->dev, "registered UART support\n");
	}

	return 0;
}

static int kempld_detect_device(struct kempld_device_data *pld)
{
	struct kempld_platform_data *pdata = pld->dev->platform_data;
	int ret;
	u8 index_reg;
	int lock_broken = 0;

	spin_lock_irqsave(&pld->lock, pld->lock_flags);

	/* Check for empty IO space */
	index_reg = ioread8(pld->io_index);
	if ((index_reg == 0xff) && (ioread8(pld->io_data) == 0xff)) {
		ret = -ENODEV;
		spin_unlock_irqrestore(&pld->lock, pld->lock_flags);
		goto err_empty_io;
	}

	pld->last_index = index_reg & ~KEMPLD_MUTEX_KEY;

	if ((index_reg & KEMPLD_MUTEX_KEY) == 0x00) {
		/* lock is currently not acquired by anyone else */
		/* on some PLD revisions we now already have acquired the
		 * mutex, so release it before continuing */

		/* We have to set the index first, to be sure to have the
		 * lock in all HW revisions */
		iowrite8(pld->last_index, pld->io_index);

		if (pdata->release_mutex)
			pdata->release_mutex(pld);
	}

	spin_unlock_irqrestore(&pld->lock, pld->lock_flags);

	/* Now really try to get the mutex, but use a timeout for the case it
	 * doesn't work */
	ret = kempld_try_get_mutex_set_index(pld, pld->last_index, 1000);
	if (ret) {
		dev_warn(pld->dev,
			 "timeout while waiting for device semaphore\n");
		if (force_unlock) {
			/* We pretend to have aqcuired the lock and go on in
			 * the hope that it was only a single error */
			dev_warn(pld->dev,
				 "force_unlock enabled - ignoring semaphore\n");
			spin_lock_irqsave(&pld->lock, pld->lock_flags);
			pld->have_mutex = 1;
			lock_broken = 1;
		} else
			goto err_get_mutex;
	}

	/* Check if the mutex works as expected */
	/* This check is left out if the lock has been broken, as it may fail
	 * if the lock gets released in the meantime by a parallel process */
	if (pdata->get_mutex_set_index && !lock_broken) {
		/* pretend to not have the mutex and try to get it, which
		 * should fail if everything works */
		pld->have_mutex = 0;
		if  (pdata->get_mutex_set_index(pld, pld->last_index, 0)
		     != -ETIMEDOUT) {
			dev_err(pld->dev, "semaphore function check failed\n");
			ret = -EIO;

			/* release the mutex anyway to be sure everything is
			 * cleaned up */
			kempld_release_mutex(pld);

			goto err_check_mutex;
		}
		pld->have_mutex = 1;
	}

	kempld_release_mutex(pld);

	/* from here on it should be save to rely on the device semaphore */

	ret = kempld_get_info(pld);
	if (ret)
		goto err_get_info;

	ret = kempld_get_features(pld);
	if (ret)
		goto err_get_features;

	dev_info(pld->dev, "Found Kontron PLD - %s (%s), spec %d.%d\n",
		 pld->info.version, kempld_get_type_string(pld),
		 pld->info.spec_major, pld->info.spec_minor);

	ret = sysfs_create_group(&pld->dev->kobj, &pld_attr_group);
	if (ret)
		goto err_create_group;

	ret = kempld_register_cells(pld);
	if (ret)
		goto err_register_functions;

	return 0;

err_register_functions:
	sysfs_remove_group(&pld->dev->kobj, &pld_attr_group);
err_create_group:
err_get_features:
err_get_info:
err_check_mutex:
err_get_mutex:
err_empty_io:
	return ret;
}

static int kempld_probe(struct platform_device *pdev)
{
	struct kempld_platform_data *pdata = pdev->dev.platform_data;
	struct resource *ioport;
	struct kempld_device_data  *pld;
	int ret;

	dev_dbg(&pdev->dev, "probing for Kontron PLD on %s\n",
		 pdata->board_id->ident);

	pld = kzalloc(sizeof(struct kempld_device_data), GFP_KERNEL);
	if (pld == NULL) {
		ret = -ENOMEM;
		goto err_alloc_dev_data;
	}

	ioport = platform_get_resource(pdev, IORESOURCE_IO, 0);
	if (!ioport) {
		ret = -EINVAL;
		goto err_get_resource;
	}

	pld->io_base = ioport_map(ioport->start, ioport->end - ioport->start);
	if (!pld->io_base) {
		ret = -ENOMEM;
		goto err_iomap;
	}

	pld->io_index = pld->io_base;
	pld->io_data = pld->io_base + 1;

	pld->pld_clock       = pdata->pld_clock;

	spin_lock_init(&pld->lock);

	pld->dev = &pdev->dev;

	platform_set_drvdata(pdev, pld);

	ret = kempld_detect_device(pld);
	if (ret)
		goto err_detect_device;

	return 0;

err_detect_device:
	ioport_unmap(pld->io_base);
err_iomap:
err_get_resource:
	kfree(pld);
err_alloc_dev_data:
	return ret;
}

static int kempld_remove(struct platform_device *pdev)
{
	struct kempld_device_data *pld = platform_get_drvdata(pdev);

	sysfs_remove_group(&pld->dev->kobj, &pld_attr_group);

	mfd_remove_devices(&pdev->dev);
	platform_set_drvdata(pdev, NULL);

	ioport_unmap(pld->io_base);

	kfree(pld);

	return 0;
}

static struct platform_driver kempld_driver = {
	.driver		= {
		.name	= "kempld",
		.owner	= THIS_MODULE,
	},
	.probe		= kempld_probe,
	.remove		= kempld_remove,
};

static int kempld_platform_device_register(const struct dmi_system_id *id)
{
	struct platform_device *pdev;
	static struct resource resource[1];
	int ret = 0;

	/* check if we already registered a kempld platform device,
	 * there can only be one */
	if (kempld_pdev != NULL) {
		ret = -EINVAL;
		goto err_device_already_registered;
	}

	/* use the generic platform data unless something else is specified */
	if (id->driver_data != NULL)
		memcpy(&kempld_platform_data, id->driver_data,
		       sizeof(kempld_platform_data));
	else
		memcpy(&kempld_platform_data, &kempld_platform_data_generic,
		       sizeof(kempld_platform_data));


	pdev = platform_device_alloc("kempld", -1);
	if (!pdev) {
		ret = -ENOMEM;
		goto err_device_alloc_failed;
	}

	kempld_platform_data.board_id = id;

	ret = platform_device_add_data(pdev, &kempld_platform_data,
				       sizeof(kempld_platform_data));
	if (ret)
		goto err_add_data_failed;

	resource[0].start = kempld_platform_data.ioport;
	resource[0].end   = kempld_platform_data.ioport + 1;
	resource[0].flags = IORESOURCE_IO;

	ret = platform_device_add_resources(pdev, resource, 1);
	if (ret)
		goto err_device_add_resources;

	ret = platform_device_add(pdev);
	if (ret)
		goto err_device_register_failed;

	kempld_pdev = pdev;

	return 0;

err_device_register_failed:
err_device_add_resources:
err_add_data_failed:
	platform_device_put(pdev);
err_device_alloc_failed:
err_device_already_registered:
	return ret;
}

static int __init kempld_init(void)
{
	int ret;

	ret = platform_driver_register(&kempld_driver);
	if (ret)
		goto err_platform_driver_register;

	/* check force parameter if a specific implementation should be
	 * probed */
	if (force_device_id[0]) {
		int found = 0;
		const struct dmi_system_id *d;

		for (d = kempld_boardids; d->matches[0].slot != DMI_NONE; d++)
			if (strstr(d->ident, force_device_id)) {
				found++;
				if (d->callback && !d->callback(d))
					break;
			}

		if (!found)
			goto err_device_not_found;

		return 0;
	}

	/* try to autodetect the board */
	if (dmi_check_system(kempld_boardids))
		return 0;

err_device_not_found:
	platform_driver_unregister(&kempld_driver);
	ret = -ENODEV;
err_platform_driver_register:
	return ret;
}

static void __exit kempld_exit(void)
{
	/* unregister device first */
	if (kempld_pdev) {
		platform_device_unregister(kempld_pdev);
		kempld_pdev = NULL;
	}

	platform_driver_unregister(&kempld_driver);
}

module_init(kempld_init);
module_exit(kempld_exit);

MODULE_DESCRIPTION("KEM PLD Core Driver");
MODULE_AUTHOR("Michael Brunner <michael.brunner@kontron.com>");
MODULE_LICENSE("GPL");
MODULE_ALIAS("platform:kempld-core");
MODULE_VERSION("33.0");
